//
//  ViewController.m
//  UIView OutletsTest (Lesson 20)
//
//  Created by Anton Gorlov on 06.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(CGFloat) randomFromZeroToOne {//дублирование кода
return  (float) (arc4random()%256)/255;
}
-(UIColor*) randomColor{
    CGFloat r=[self randomFromZeroToOne];//,берем байт число от "0" до "255".Берем остаток от деления на 256.
    CGFloat g=[self randomFromZeroToOne];
    CGFloat b=[self randomFromZeroToOne];
    return  [UIColor colorWithRed:r green:g/256 blue:b alpha:1.f];
}
//соз случайный цвет.
-(void) viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    for (UIView* v in self.testVews){
        v.backgroundColor=[self randomColor];
    }

}
@end
