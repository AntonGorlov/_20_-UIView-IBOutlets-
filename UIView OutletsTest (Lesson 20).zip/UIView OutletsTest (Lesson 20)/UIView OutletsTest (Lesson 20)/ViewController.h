//
//  ViewController.h
//  UIView OutletsTest (Lesson 20)
//
//  Created by Anton Gorlov on 06.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *testVews;

@end

