//
//  ViewController.m
//  HomeWork Lesson 20 (UIView OutLets)
//
//  Created by Anton Gorlov on 11.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

//рисуем все вручную!!!а не как в пред.задании

@end

@implementation ViewController
-(CGFloat) colorRGB {
    return (float)(arc4random()%256)/255;
}
-(UIColor*) randomColor {
    CGFloat r=[self colorRGB];
    CGFloat g=[self colorRGB];
    CGFloat b=[self colorRGB];
    return [UIColor colorWithRed:r green:g blue:b alpha:1];
}

- (UIColor*) normColors {
    int i = arc4random() % 5;// 5 цветов в рендоме
    UIColor* color;
    switch (i) {
        case 1:
            return color = [UIColor blackColor];
            break;
            
        case 2:
            return color = [UIColor purpleColor];
            break;
            
        case 3:
            return color = [UIColor blueColor];
            break;
        case 4:
            return  color =[UIColor greenColor];
            break;
        case 5:
            return  color=[UIColor yellowColor];
            break;
    }
    return color;
}


/*
 На самом деле урок очень простой, единственно что я рекомендую повторить прошлое домашнее задание, но используя аутлеты. Итак:
 
 ВСЕ ЗАДАНИЯ ДОЛЖНЫ БЫТЬ БЫПОЛНЕНЫ ТОЛЬКО ИСПОЛЬЗУЯ АУТЛЕТЫ.
 МЕТОД subviews НЕ ИСПОЛЬЗУЙТЕ, ВМЕСТО НЕГО ИСПОЛЬЗУЙТЕ АУТЛЕТ КОЛЛЕКЦИИ
 
 Ученик
 
 1. В цикле создавайте квадратные UIView с черным фоном и расположите их в виде шахматной доски
 2. доска должна иметь столько клеток, как и настоящая шахматная
 
 Студент
 
 3. Доска должна быть вписана в максимально возможный квадрат, т.е. либо бока, либо верх или низ должны касаться границ экрана
 4. Применяя соответствующие маски сделайте так, чтобы когда устройство меняет ориентацию, то все клетки растягивались соответственно и ничего не вылетало за пределы экрана.
 
 Мастер
 5. При повороте устройства все черные клетки должны менять цвет :)
 6.Сделайте так, чтобы доска при поворотах всегда строго находилась по центру
 
 Супермен
 8. Поставьте белые и красные шашки (квадратные вьюхи) так как они стоят на доске. Они должны быть сабвьюхами главной вьюхи (у них и у клеток один супервью)
 9. После каждого переворота шашки должны быть перетасованы используя соответствующие методы иерархии UIView (перетаскивать вьюхи надо стрелочками клавиатуры!!!!!)
*/
 
- (void)viewDidLoad {
    [super viewDidLoad];
    //Делаем круглые шашки
    for (UIView* redCells in self.redCkeckers) {
        redCells.layer.cornerRadius = 15;
    }
    for(UIView* whiteCells in self.whiteCkeckers){
        whiteCells.layer.cornerRadius=15;
    }
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotate {
    return YES;
}
-(UIInterfaceOrientationMask) supportedInterfaceOrientations {
    return  UIInterfaceOrientationMaskAll;
}


-(void) viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
   /* Черные клетки разноцветные
    for (UIView* black in self.blackRandomColor){
        black.backgroundColor=[self randomColor];
    }
   */
   //смена черных клеток на случайный цвет (5 шт.)
    UIColor* randomOfFive = [self normColors];
    
    for (UIView* cells in self.blackRandomColor) {
        cells.backgroundColor =randomOfFive;
    }
    //9. После каждого переворота шашки должны быть перетасованы используя соответствующие методы иерархии UIView
    for (int i = 0; i<[self.сhessBoard.subviews count]; i++) {
         UIView* subView = [self.сhessBoard.subviews objectAtIndex:i];
        if (subView.tag == 1) {
            while (YES){
            NSUInteger randomIndex = arc4random()%[self.сhessBoard.subviews count];
                UIView* subView2 = [self.сhessBoard.subviews objectAtIndex:randomIndex];
                if (subView2.tag == 1 && ![subView isEqual:subView2]){
                    CGRect frame = subView.frame;
                    subView.frame = CGRectMake(subView2.frame.origin.x, subView2.frame.origin.y, subView2.frame.size.width, subView2.frame.size.height);
                     subView2.frame = CGRectMake(frame.origin.x, frame.origin.y, subView2.frame.size.width, subView2.frame.size.height);
                    [self.сhessBoard exchangeSubviewAtIndex:i withSubviewAtIndex:randomIndex];
                    break;

                }
            }
        }
    }
}




@end
