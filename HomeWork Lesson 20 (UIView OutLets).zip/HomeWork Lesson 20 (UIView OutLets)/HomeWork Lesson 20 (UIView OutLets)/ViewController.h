//
//  ViewController.h
//  HomeWork Lesson 20 (UIView OutLets)
//
//  Created by Anton Gorlov on 11.01.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *сhessBoard;

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *blackRandomColor;


@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *redCkeckers;

@property (strong, nonatomic) IBOutletCollection(UIView) NSArray *whiteCkeckers;



@end

